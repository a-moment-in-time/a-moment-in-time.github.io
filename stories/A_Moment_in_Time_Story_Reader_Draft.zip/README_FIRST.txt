A MOMENT IN TIME — STORY READER TEST PACK (FIRST DRAFT)
======================================================
This is a new story reader; it does NOT change the existing biography
page or the main World Codex.

FILES TO COPY INTO YOUR LOCAL WEBSITE:
  stories/index.html         Shared reader (HTML + CSS + JavaScript)
  stories/template.txt       Copy for authors to format their stories
  stories/example-story.txt  Demo with 3 chapters and optional fields

The /stories/ folder must sit at the SAME LEVEL as /profiles/.
The reader loads ../style.css from the existing site automatically.

TEST URLS (once published to GitHub Pages):
  https://a-moment-in-time.github.io/stories/index.html?story=example-story
  https://a-moment-in-time.github.io/stories/index.html?story=example-story&chapter=2

To add a story: copy template.txt to stories/<your-slug>.txt, fill it out,
then link readers to stories/index.html?story=<your-slug>.
Only lowercase letters/numbers/hyphens/underscores for the filename slug.

Unlimited chapters are discovered from [CHAPTER_1], [CHAPTER_2], etc.
Add the matching [CHAPTER_#_TITLE] if you want a custom chapter title.
Only chapters with body text display. Optional metadata is hidden if blank.

A one-chapter story hides the chapter navigation entirely.
Previous / Next buttons + chapter dropdown generate shareable chapter
URLs and work with browser Back/Forward history.

This demo DOES NOT create or modify the Logs & Stories listing yet.
The main World Codex already has that section; it still needs a future
listing page. For now, open the example URLs directly.

IMPORTANT:
- Browser fetch generally will not work with a raw file:/// URL.
  Run through a local HTTP server or publish a test copy to GitHub Pages.
- Story bodies support HTML formatting, as the existing bios do. Only
  publish reviewed/trusted story .txt files.
- AO3 is optional: leave [AO3] blank until you have a real story URL.
- No files were written or uploaded to your connected GitHub repository.
======================================================
